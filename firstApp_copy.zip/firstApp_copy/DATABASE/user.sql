create table users(
id varchar2(10) primary key,
pwd varchar2(10)
)